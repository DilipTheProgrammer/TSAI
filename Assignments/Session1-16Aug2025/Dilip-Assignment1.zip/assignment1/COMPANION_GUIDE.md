# CNN Kernel Visualizer Companion Guide

## Quick Start Guide

### 1. Understanding the Interface

The CNN Kernel Visualizer has three main sections:

1. **Input Pane** (Left): Load protein sequences and configure CNN parameters
2. **Visualization Area** (Center): Real-time kernel scanning and activation plots
3. **Results Panel** (Right): Discovered motifs and sequence logos

### 2. Basic Workflow

1. **Load a Sequence**: Choose from demo sequences or upload your own FASTA file
2. **Configure Parameters**: Adjust kernel width, stride, and number of kernels
3. **Run Analysis**: Watch the kernels scan across the sequence
4. **Analyze Results**: Examine high-activation positions and discovered motifs

## Parameter Configuration Guide

### Kernel Width (3-10 amino acids)
- **Small width (3-4)**: Detects short motifs like phosphorylation sites
- **Medium width (5-7)**: Good for most protein domains
- **Large width (8-10)**: Detects longer structural motifs

### Stride (1-5 positions)
- **Stride 1**: Maximum resolution, slower computation
- **Stride 2-3**: Good balance of speed and accuracy
- **Stride 4-5**: Faster computation, may miss some motifs

### Number of Kernels (1-5)
- **1 Kernel**: Focus on one specific amino acid type
- **2-3 Kernels**: Good for most analyses
- **4-5 Kernels**: Comprehensive analysis of different amino acid properties

## Understanding the Kernels

### Kernel 1: Small Amino Acid Detector
**Targets**: G, A, S
**Biological Context**: 
- Small amino acids often found in flexible regions
- Common in ATP binding sites (GXGXXG motif)
- Important for protein folding and flexibility

**Expected High Activations**:
- Glycine-rich regions
- Flexible loops and turns
- ATP binding sites

### Kernel 2: Basic Amino Acid Detector
**Targets**: R, K, H
**Biological Context**:
- Basic amino acids involved in DNA/RNA binding
- Common in zinc finger domains
- Important for protein-nucleic acid interactions

**Expected High Activations**:
- DNA binding domains
- Zinc finger motifs
- Nuclear localization signals

### Kernel 3: Acidic Amino Acid Detector
**Targets**: D, E, N
**Biological Context**:
- Acidic amino acids often in catalytic sites
- Important for enzyme function
- Common in calcium binding sites

**Expected High Activations**:
- Catalytic sites
- Calcium binding motifs
- Enzyme active sites

## Interpreting Results

### Activation Values
- **0.0-0.3**: Low activation, unlikely to be significant
- **0.3-0.6**: Medium activation, worth investigating
- **0.6-1.0**: High activation, likely biologically significant

### High Activation Positions
Look for:
1. **Clusters** of high activations (not just single peaks)
2. **Consistent patterns** across multiple kernels
3. **Overlap** with known biological motifs
4. **Biological context** (e.g., kinase domains should show ATP binding sites)

### Sequence Logos
- **Tall bars**: Strong preference for specific amino acids
- **Short bars**: Variable amino acid preferences
- **Consistent patterns**: Indicates functional motifs

## Troubleshooting Guide

### Common Issues and Solutions

#### Issue: No High Activations Detected
**Possible Causes**:
- Kernel width too large for the sequence
- Stride too large, missing motifs
- Sequence doesn't contain target amino acid types

**Solutions**:
- Reduce kernel width to 3-5
- Reduce stride to 1-2
- Try different demo sequences
- Check if sequence contains target amino acid types

#### Issue: Too Many High Activations
**Possible Causes**:
- Threshold too low
- Kernel width too small
- Sequence has repetitive patterns

**Solutions**:
- Increase activation threshold
- Increase kernel width
- Use more specific kernel configurations

#### Issue: Motifs Not Matching Known Patterns
**Possible Causes**:
- Similarity threshold too high
- Motif definitions too strict
- Sequence variations not accounted for

**Solutions**:
- Lower similarity threshold (try 0.6 instead of 0.7)
- Check motif definitions in demo sequences
- Consider biological variations in motifs

### Performance Optimization

#### For Long Sequences (>1000 amino acids)
- Increase stride to 2-3
- Reduce number of kernels to 2-3
- Use higher activation thresholds

#### For Real-time Analysis
- Reduce kernel width
- Increase stride
- Limit number of kernels

## Advanced Usage

### Custom Kernel Weights

You can modify kernel weights in the code to target specific patterns:

```typescript
// Example: Create a hydrophobic amino acid detector
const hydrophobicKernel = [0.8, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.9, 0.9, 0.0, 0.8, 0.9, 0.0, 0.0, 0.0, 0.0, 0.9, 0.9]
// Targets: I, L, M, F, V (hydrophobic amino acids)
```

### Custom Amino Acid Similarity

Modify the similarity matrix for specific applications:

```typescript
// Example: Increase similarity between basic amino acids
const customSimilarity = {
  'R': { 'R': 1.0, 'K': 0.9, 'H': 0.8 }, // Higher similarity
  'K': { 'R': 0.9, 'K': 1.0, 'H': 0.8 },
  'H': { 'R': 0.8, 'K': 0.8, 'H': 1.0 }
}
```

### Export and Analysis

#### JSON Export Format
```json
{
  "sequence": "Protein Name",
  "kernel": 1,
  "highActivationPositions": [
    {
      "position": 45,
      "subsequence": "GXGXXG",
      "activation": 0.85,
      "matchedMotifs": [
        {
          "name": "ATP binding site",
          "confidence": 0.9
        }
      ]
    }
  ],
  "sequenceLogo": [
    {
      "position": 0,
      "aminoAcids": {"G": 0.8, "A": 0.2},
      "height": 0.8
    }
  ]
}
```

#### Further Analysis
- Import results into bioinformatics tools
- Compare with protein databases
- Validate predictions experimentally
- Use for machine learning training data

## Educational Applications

### For Students
1. **Start with Demo Sequences**: Understand basic concepts
2. **Experiment with Parameters**: See how changes affect results
3. **Compare Different Proteins**: Understand motif diversity
4. **Validate Predictions**: Check against known motifs

### For Educators
1. **Demonstrate CNN Concepts**: Show convolution in action
2. **Explain Biological Context**: Connect AI to protein biology
3. **Interactive Learning**: Let students explore parameters
4. **Assessment Tool**: Have students predict and validate motifs

### For Researchers
1. **Prototype New Kernels**: Test different pattern detectors
2. **Validate Approaches**: Compare with existing methods
3. **Generate Hypotheses**: Discover potential new motifs
4. **Educational Outreach**: Explain research to non-experts

## Best Practices

### Data Quality
- Use high-quality protein sequences
- Verify sequence annotations
- Consider sequence context
- Account for sequence variations

### Analysis Workflow
1. Start with known sequences
2. Validate against known motifs
3. Experiment with parameters
4. Document findings
5. Share results

### Interpretation
- Consider biological context
- Look for patterns, not just peaks
- Validate with multiple methods
- Be cautious of false positives

## Future Enhancements

### Planned Features
- **Multiple Sequence Alignment**: Compare motifs across proteins
- **3D Structure Integration**: Visualize motifs in protein structures
- **Machine Learning Training**: Train custom kernels
- **Database Connectivity**: Access protein databases

### Extensibility
- **Plugin Architecture**: Add custom visualizations
- **API Integration**: Connect to external tools
- **Custom Kernels**: User-defined kernel weights
- **Batch Processing**: Analyze multiple sequences

## Support and Resources

### Documentation
- Read the main tutorial for technical details
- Check the README for installation instructions
- Review the code comments for implementation details

### Community
- Share results and findings
- Contribute improvements
- Report bugs and issues
- Suggest new features

### Learning Resources
- Protein structure databases (PDB)
- Motif databases (PROSITE, Pfam)
- Bioinformatics tutorials
- Deep learning resources

---

**Happy exploring! 🧬🧠✨**

This companion guide should help you get the most out of the CNN Kernel Visualizer. Remember to experiment, validate your findings, and share your discoveries with the community.
