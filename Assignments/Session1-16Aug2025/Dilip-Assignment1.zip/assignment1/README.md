# CNN Kernel Visualizer for Protein Motif Discovery

An interactive web-based visual explainer that demystifies how Convolutional Neural Networks (CNNs) detect motifs and domains in protein sequences. This tool is designed for biologists, educators, and students to understand the inner workings of CNNs through step-by-step animations and visualizations.

## Features

### 🧬 Interactive Protein Sequence Analysis
- **Sequence Input**: Upload FASTA files or paste protein sequences manually
- **Demo Sequences**: Pre-loaded examples including kinase domains, zinc fingers, and transmembrane proteins
- **Real-time Processing**: Instant CNN computation and visualization

### 🎯 CNN Kernel Visualization
- **Animated Scanning**: Watch kernels slide across protein sequences in real-time
- **Activation Plots**: Visualize how strongly each kernel responds at different positions
- **Kernel Controls**: Adjust kernel width, stride, and number of kernels
- **Step-by-step Mode**: Manual control for educational purposes

### 🔍 Motif Discovery & Analysis
- **Motif Extraction**: Automatically identify high-activation subsequences
- **Sequence Logos**: Generate position weight matrices for discovered motifs
- **Known Motif Matching**: Compare discovered motifs with biological databases
- **Export Results**: Download analysis results in JSON format

### 📊 Educational Features
- **Biology-Aligned Interface**: All outputs mapped to familiar biological concepts
- **Interactive Explanations**: Contextual tooltips and help sections
- **Visual Metaphors**: Kernel operations explained through biological analogies
- **No-Code Required**: Designed for users without programming experience

## Technology Stack

- **Frontend**: React 18 with TypeScript
- **Styling**: Tailwind CSS with custom amino acid color scheme
- **Animations**: Framer Motion for smooth transitions
- **Visualizations**: Custom D3.js-inspired components
- **Build Tool**: Vite for fast development and building

## Installation & Setup

### Prerequisites
- Node.js (version 16 or higher)
- npm or yarn package manager

### Quick Start

1. **Clone or navigate to the project directory**
   ```bash
   cd assignment1
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Start the development server**
   ```bash
   npm run dev
   ```

4. **Open your browser**
   Navigate to `http://localhost:3000` to see the application

### Build for Production

```bash
npm run build
```

The built files will be in the `dist` directory.

## How to Use

### 1. Load a Protein Sequence
- **Demo Sequences**: Click "Show Examples" and select from pre-loaded sequences
- **File Upload**: Drag and drop a FASTA file or click "Choose File"
- **Manual Input**: Paste a protein sequence in one-letter amino acid code

### 2. Configure CNN Parameters
- **Kernel Width**: Adjust the size of the scanning window (3-10 amino acids)
- **Stride**: Control how many positions the kernel moves each step (1-5)
- **Number of Kernels**: Set how many different pattern detectors to use (1-5)

### 3. Explore the Visualization
- **Select a Kernel**: Choose which kernel to focus on
- **Step Through**: Use manual controls or auto-play to see the scanning process
- **Watch Activations**: Observe how kernels respond to different sequence patterns

### 4. Analyze Results
- **High Activation Sites**: Identify where kernels strongly respond
- **Sequence Logos**: See amino acid preferences at each position
- **Motif Matching**: Compare with known biological motifs
- **Export Data**: Download results for further analysis

## Educational Value

### For Students
- **Visual Learning**: See abstract CNN concepts in concrete biological terms
- **Interactive Exploration**: Experiment with parameters to understand their effects
- **Biological Context**: Learn how AI relates to real protein biology

### For Educators
- **Teaching Tool**: Use in lectures to explain CNN concepts
- **Demonstration Platform**: Show real examples of motif discovery
- **Assessment**: Students can explore and report on their findings

### For Researchers
- **Prototype Testing**: Validate CNN approaches on protein sequences
- **Parameter Optimization**: Experiment with different kernel configurations
- **Result Visualization**: Generate publication-ready figures

## Technical Details

### CNN Implementation
- **Convolution Operation**: Simplified 1D convolution with amino acid similarity
- **Activation Function**: ReLU-like activation with biological constraints
- **Kernel Weights**: Pre-configured weights that prefer different amino acid types
- **Motif Matching**: Sequence similarity scoring with known biological motifs

### Data Structures
- **Protein Sequences**: FASTA format support with metadata
- **Activation Maps**: Position-wise activation values for each kernel
- **Motif Definitions**: Biological motif databases with confidence scores
- **Sequence Logos**: Position weight matrices for motif visualization

### Performance Considerations
- **Real-time Computation**: Optimized for immediate visual feedback
- **Memory Efficient**: Handles sequences up to several thousand amino acids
- **Responsive Design**: Works on desktop and tablet devices

## Future Enhancements

### Planned Features
- **Multiple Sequence Alignment**: Compare motifs across related proteins
- **Advanced Visualization**: 3D protein structure integration
- **Machine Learning Integration**: Train custom kernels on user data
- **Database Connectivity**: Real-time access to protein databases

### Extensibility
- **Plugin Architecture**: Support for custom visualization components
- **API Integration**: Connect to external bioinformatics tools
- **Custom Kernels**: User-defined kernel weight configurations

## Contributing

This project is designed as an educational tool. Contributions are welcome in the following areas:

- **Educational Content**: Improve explanations and tutorials
- **Visualization Enhancements**: Better graphics and animations
- **Biological Accuracy**: More accurate motif detection algorithms
- **User Experience**: Interface improvements and accessibility

## License

MIT License - see LICENSE file for details.

## Acknowledgments

- Inspired by the Polo Club of Data Science's approach to deep learning education
- Built for the CNN Assignment 1 Session 1 project
- Uses standard bioinformatics conventions and protein sequence formats

## Support

For questions or issues:
1. Check the "How it Works" section in the application
2. Review the demo sequences for examples
3. Experiment with different parameters to understand their effects

---

**Happy exploring! 🧬🧠✨**

