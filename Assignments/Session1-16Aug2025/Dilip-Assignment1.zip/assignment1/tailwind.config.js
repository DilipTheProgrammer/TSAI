/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        primary: {
          50: '#eff6ff',
          100: '#dbeafe',
          200: '#bfdbfe',
          300: '#93c5fd',
          400: '#60a5fa',
          500: '#3b82f6',
          600: '#2563eb',
          700: '#1d4ed8',
          800: '#1e40af',
          900: '#1e3a8a',
        },
        amino: {
          A: '#FF6B6B', // Alanine
          R: '#4ECDC4', // Arginine
          N: '#45B7D1', // Asparagine
          D: '#96CEB4', // Aspartic acid
          C: '#FFEAA7', // Cysteine
          E: '#DDA0DD', // Glutamic acid
          Q: '#98D8C8', // Glutamine
          G: '#F7DC6F', // Glycine
          H: '#BB8FCE', // Histidine
          I: '#85C1E9', // Isoleucine
          L: '#F8C471', // Leucine
          K: '#82E0AA', // Lysine
          M: '#F1948A', // Methionine
          F: '#85C1E9', // Phenylalanine
          P: '#F7DC6F', // Proline
          S: '#D7BDE2', // Serine
          T: '#A9CCE3', // Threonine
          W: '#F8C471', // Tryptophan
          Y: '#FAD7A0', // Tyrosine
          V: '#ABEBC6', // Valine
        }
      },
      animation: {
        'slide-in': 'slideIn 0.5s ease-out',
        'fade-in': 'fadeIn 0.3s ease-out',
        'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
      },
      keyframes: {
        slideIn: {
          '0%': { transform: 'translateX(-100%)', opacity: '0' },
          '100%': { transform: 'translateX(0)', opacity: '1' },
        },
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
      },
    },
  },
  plugins: [],
}

