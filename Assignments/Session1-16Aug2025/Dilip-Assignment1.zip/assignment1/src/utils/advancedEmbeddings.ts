import { ProteinSequence } from '../types'

// BLOSUM62 substitution matrix (Henikoff & Henikoff, 1992)
// This is the standard matrix used in protein sequence analysis
export const BLOSUM62: { [key: string]: { [key: string]: number } } = {
  'A': { 'A': 4, 'R': -1, 'N': -2, 'D': -2, 'C': 0, 'Q': -1, 'E': -1, 'G': 0, 'H': -2, 'I': -1, 'L': -1, 'K': -1, 'M': -1, 'F': -2, 'P': -1, 'S': 1, 'T': 0, 'W': -3, 'Y': -2, 'V': 0 },
  'R': { 'A': -1, 'R': 5, 'N': 0, 'D': -2, 'C': -3, 'Q': 1, 'E': 0, 'G': -2, 'H': 0, 'I': -3, 'L': -2, 'K': 2, 'M': -1, 'F': -3, 'P': -2, 'S': -1, 'T': -1, 'W': -3, 'Y': -2, 'V': -3 },
  'N': { 'A': -2, 'R': 0, 'N': 6, 'D': 1, 'C': -3, 'Q': 0, 'E': 0, 'G': 0, 'H': 1, 'I': -3, 'L': -3, 'K': 0, 'M': -2, 'F': -3, 'P': -2, 'S': 1, 'T': 0, 'W': -4, 'Y': -2, 'V': -3 },
  'D': { 'A': -2, 'R': -2, 'N': 1, 'D': 6, 'C': -3, 'Q': 0, 'E': 2, 'G': -1, 'H': -1, 'I': -3, 'L': -4, 'K': -1, 'M': -3, 'F': -3, 'P': -1, 'S': 0, 'T': -1, 'W': -4, 'Y': -3, 'V': -3 },
  'C': { 'A': 0, 'R': -3, 'N': -3, 'D': -3, 'C': 9, 'Q': -3, 'E': -4, 'G': -3, 'H': -3, 'I': -1, 'L': -1, 'K': -3, 'M': -1, 'F': -2, 'P': -3, 'S': -1, 'T': -1, 'W': -2, 'Y': -2, 'V': -1 },
  'Q': { 'A': -1, 'R': 1, 'N': 0, 'D': 0, 'C': -3, 'Q': 5, 'E': 2, 'G': -2, 'H': 0, 'I': -3, 'L': -2, 'K': 1, 'M': 0, 'F': -3, 'P': -1, 'S': 0, 'T': -1, 'W': -2, 'Y': -1, 'V': -2 },
  'E': { 'A': -1, 'R': 0, 'N': 0, 'D': 2, 'C': -4, 'Q': 2, 'E': 5, 'G': -2, 'H': 0, 'I': -3, 'L': -3, 'K': 1, 'M': -2, 'F': -3, 'P': -1, 'S': 0, 'T': -1, 'W': -3, 'Y': -2, 'V': -2 },
  'G': { 'A': 0, 'R': -2, 'N': 0, 'D': -1, 'C': -3, 'Q': -2, 'E': -2, 'G': 6, 'H': -2, 'I': -4, 'L': -4, 'K': -2, 'M': -3, 'F': -3, 'P': -2, 'S': 0, 'T': -2, 'W': -2, 'Y': -3, 'V': -3 },
  'H': { 'A': -2, 'R': 0, 'N': 1, 'D': -1, 'C': -3, 'Q': 0, 'E': 0, 'G': -2, 'H': 8, 'I': -3, 'L': -3, 'K': -1, 'M': -2, 'F': -1, 'P': -2, 'S': -1, 'T': -2, 'W': -2, 'Y': 2, 'V': -3 },
  'I': { 'A': -1, 'R': -3, 'N': -3, 'D': -3, 'C': -1, 'Q': -3, 'E': -3, 'G': -4, 'H': -3, 'I': 4, 'L': 2, 'K': -3, 'M': 1, 'F': 0, 'P': -3, 'S': -2, 'T': -1, 'W': -3, 'Y': -1, 'V': 3 },
  'L': { 'A': -1, 'R': -2, 'N': -3, 'D': -4, 'C': -1, 'Q': -2, 'E': -3, 'G': -4, 'H': -3, 'I': 2, 'L': 4, 'K': -2, 'M': 2, 'F': 0, 'P': -3, 'S': -2, 'T': -1, 'W': -2, 'Y': -1, 'V': 1 },
  'K': { 'A': -1, 'R': 2, 'N': 0, 'D': -1, 'C': -3, 'Q': 1, 'E': 1, 'G': -2, 'H': -1, 'I': -3, 'L': -2, 'K': 5, 'M': -1, 'F': -3, 'P': -1, 'S': 0, 'T': -1, 'W': -3, 'Y': -2, 'V': -2 },
  'M': { 'A': -1, 'R': -1, 'N': -2, 'D': -3, 'C': -1, 'Q': 0, 'E': -2, 'G': -3, 'H': -2, 'I': 1, 'L': 2, 'K': -1, 'M': 5, 'F': 0, 'P': -2, 'S': -1, 'T': -1, 'W': -1, 'Y': -1, 'V': 1 },
  'F': { 'A': -2, 'R': -3, 'N': -3, 'D': -3, 'C': -2, 'Q': -3, 'E': -3, 'G': -3, 'H': -1, 'I': 0, 'L': 0, 'K': -3, 'M': 0, 'F': 6, 'P': -4, 'S': -2, 'T': -2, 'W': 1, 'Y': 3, 'V': -1 },
  'P': { 'A': -1, 'R': -2, 'N': -2, 'D': -1, 'C': -3, 'Q': -1, 'E': -1, 'G': -2, 'H': -2, 'I': -3, 'L': -3, 'K': -1, 'M': -2, 'F': -4, 'P': 7, 'S': -1, 'T': -1, 'W': -4, 'Y': -3, 'V': -2 },
  'S': { 'A': 1, 'R': -1, 'N': 1, 'D': 0, 'C': -1, 'Q': 0, 'E': 0, 'G': 0, 'H': -1, 'I': -2, 'L': -2, 'K': 0, 'M': -1, 'F': -2, 'P': -1, 'S': 4, 'T': 1, 'W': -3, 'Y': -2, 'V': -2 },
  'T': { 'A': 0, 'R': -1, 'N': 0, 'D': -1, 'C': -1, 'Q': -1, 'E': -1, 'G': -2, 'H': -2, 'I': -1, 'L': -1, 'K': -1, 'M': -1, 'F': -2, 'P': -1, 'S': 1, 'T': 5, 'W': -2, 'Y': -2, 'V': 0 },
  'W': { 'A': -3, 'R': -3, 'N': -4, 'D': -4, 'C': -2, 'Q': -2, 'E': -3, 'G': -2, 'H': -2, 'I': -3, 'L': -2, 'K': -3, 'M': -1, 'F': 1, 'P': -4, 'S': -3, 'T': -2, 'W': 11, 'Y': 2, 'V': -3 },
  'Y': { 'A': -2, 'R': -2, 'N': -2, 'D': -3, 'C': -2, 'Q': -1, 'E': -2, 'G': -3, 'H': 2, 'I': -1, 'L': -1, 'K': -2, 'M': -1, 'F': 3, 'P': -3, 'S': -2, 'T': -2, 'W': 2, 'Y': 7, 'V': -1 },
  'V': { 'A': 0, 'R': -3, 'N': -3, 'D': -3, 'C': -1, 'Q': -2, 'E': -2, 'G': -3, 'H': -3, 'I': 3, 'L': 1, 'K': -2, 'M': 1, 'F': -1, 'P': -2, 'S': -2, 'T': 0, 'W': -3, 'Y': -1, 'V': 4 }
}

// Amino acid physicochemical properties (Kyte-Doolittle scale for hydrophobicity)
export const aminoAcidProperties = {
  'A': { hydrophobicity: 1.8, charge: 0, polarity: 0, size: 89, flexibility: 0.357 },
  'R': { hydrophobicity: -4.5, charge: 1, polarity: 1, size: 174, flexibility: 0.529 },
  'N': { hydrophobicity: -3.5, charge: 0, polarity: 1, size: 132, flexibility: 0.463 },
  'D': { hydrophobicity: -3.5, charge: -1, polarity: 1, size: 133, flexibility: 0.511 },
  'C': { hydrophobicity: 2.5, charge: 0, polarity: 0, size: 121, flexibility: 0.346 },
  'Q': { hydrophobicity: -3.5, charge: 0, polarity: 1, size: 146, flexibility: 0.493 },
  'E': { hydrophobicity: -3.5, charge: -1, polarity: 1, size: 147, flexibility: 0.497 },
  'G': { hydrophobicity: -0.4, charge: 0, polarity: 0, size: 75, flexibility: 0.544 },
  'H': { hydrophobicity: -3.2, charge: 0.1, polarity: 1, size: 155, flexibility: 0.323 },
  'I': { hydrophobicity: 4.5, charge: 0, polarity: 0, size: 131, flexibility: 0.462 },
  'L': { hydrophobicity: 3.8, charge: 0, polarity: 0, size: 131, flexibility: 0.365 },
  'K': { hydrophobicity: -3.9, charge: 1, polarity: 1, size: 146, flexibility: 0.466 },
  'M': { hydrophobicity: 1.9, charge: 0, polarity: 0, size: 149, flexibility: 0.295 },
  'F': { hydrophobicity: 2.8, charge: 0, polarity: 0, size: 165, flexibility: 0.314 },
  'P': { hydrophobicity: -1.6, charge: 0, polarity: 0, size: 115, flexibility: 0.509 },
  'S': { hydrophobicity: -0.8, charge: 0, polarity: 1, size: 105, flexibility: 0.507 },
  'T': { hydrophobicity: -0.7, charge: 0, polarity: 1, size: 119, flexibility: 0.444 },
  'W': { hydrophobicity: -0.9, charge: 0, polarity: 0, size: 204, flexibility: 0.305 },
  'Y': { hydrophobicity: -1.3, charge: 0, polarity: 1, size: 181, flexibility: 0.420 },
  'V': { hydrophobicity: 4.2, charge: 0, polarity: 0, size: 117, flexibility: 0.386 }
}

// Position-specific scoring matrix (PSSM) for common motifs
export const motifPSSMs = {
  'ATP_BINDING': [
    { 'G': 0.8, 'A': 0.1, 'S': 0.1 }, // Position 1: G preferred
    { 'X': 1.0 }, // Position 2: any amino acid
    { 'G': 0.7, 'A': 0.2, 'S': 0.1 }, // Position 3: G preferred
    { 'X': 1.0 }, // Position 4: any amino acid
    { 'X': 1.0 }, // Position 5: any amino acid
    { 'G': 0.6, 'A': 0.3, 'S': 0.1 }  // Position 6: G preferred
  ],
  'ZINC_FINGER': [
    { 'C': 0.9, 'S': 0.1 }, // C2H2 pattern
    { 'X': 1.0 },
    { 'E': 0.8, 'D': 0.2 },
    { 'C': 0.9, 'S': 0.1 },
    { 'G': 0.7, 'A': 0.3 },
    { 'K': 0.6, 'R': 0.3, 'H': 0.1 },
    { 'S': 0.6, 'T': 0.3, 'A': 0.1 }
  ],
  'SIGNAL_PEPTIDE': [
    { 'M': 0.8, 'A': 0.2 }, // N-terminal methionine
    { 'A': 0.4, 'L': 0.3, 'V': 0.2, 'I': 0.1 }, // Hydrophobic
    { 'L': 0.4, 'A': 0.3, 'V': 0.2, 'I': 0.1 }, // Hydrophobic
    { 'L': 0.4, 'A': 0.3, 'V': 0.2, 'I': 0.1 }, // Hydrophobic
    { 'L': 0.4, 'A': 0.3, 'V': 0.2, 'I': 0.1 }, // Hydrophobic
    { 'L': 0.4, 'A': 0.3, 'V': 0.2, 'I': 0.1 }  // Hydrophobic
  ]
}

// Enhanced amino acid embedding with multiple features
export function createAminoAcidEmbedding(aa: string, position: number, context: string = ''): number[] {
  const props = aminoAcidProperties[aa] || aminoAcidProperties['A']
  
  // Normalize properties to [0,1] range
  const normalizedProps = {
    hydrophobicity: (props.hydrophobicity + 4.5) / 9.0, // Range: -4.5 to 4.5
    charge: (props.charge + 1) / 2, // Range: -1 to 1
    polarity: props.polarity, // Binary: 0 or 1
    size: (props.size - 75) / 129, // Range: 75 to 204
    flexibility: props.flexibility // Range: 0.295 to 0.544
  }
  
  // Position encoding (sinusoidal)
  const posEncoding = [
    Math.sin(position / 10000),
    Math.cos(position / 10000),
    Math.sin(position / 10000 / 100),
    Math.cos(position / 10000 / 100)
  ]
  
  // Context features (simplified)
  const contextFeatures = context.length > 0 ? [1, 0] : [0, 1]
  
  return [
    ...Object.values(normalizedProps),
    ...posEncoding,
    ...contextFeatures
  ]
}

// Calculate BLOSUM62 similarity score
export function calculateBLOSUMSimilarity(aa1: string, aa2: string): number {
  const score = BLOSUM62[aa1]?.[aa2] || -4 // Default penalty for unknown
  return (score + 4) / 15 // Normalize to [0,1] range
}

// Calculate physicochemical similarity
export function calculatePhysicochemicalSimilarity(aa1: string, aa2: string): number {
  const props1 = aminoAcidProperties[aa1] || aminoAcidProperties['A']
  const props2 = aminoAcidProperties[aa2] || aminoAcidProperties['A']
  
  const hydrophobicityDiff = Math.abs(props1.hydrophobicity - props2.hydrophobicity) / 9.0
  const chargeDiff = Math.abs(props1.charge - props2.charge) / 2.0
  const polarityDiff = Math.abs(props1.polarity - props2.polarity)
  const sizeDiff = Math.abs(props1.size - props2.size) / 129.0
  const flexibilityDiff = Math.abs(props1.flexibility - props2.flexibility) / 0.249
  
  return 1 - (hydrophobicityDiff + chargeDiff + polarityDiff + sizeDiff + flexibilityDiff) / 5
}

// Calculate motif score using PSSM
export function calculateMotifScore(subsequence: string, motifType: string): number {
  const pssm = motifPSSMs[motifType]
  if (!pssm || subsequence.length !== pssm.length) return 0
  
  let score = 0
  for (let i = 0; i < subsequence.length; i++) {
    const aa = subsequence[i]
    const positionScores = pssm[i]
    
    if (positionScores['X']) {
      score += positionScores['X'] // Any amino acid
    } else if (positionScores[aa]) {
      score += positionScores[aa]
    } else {
      score += 0.1 // Penalty for non-preferred amino acid
    }
  }
  
  return score / subsequence.length
}

// Enhanced sequence similarity calculation
export function calculateEnhancedSimilarity(seq1: string, seq2: string): number {
  if (seq1.length !== seq2.length || seq1.length === 0) return 0
  
  let totalScore = 0
  for (let i = 0; i < seq1.length; i++) {
    const aa1 = seq1[i]
    const aa2 = seq2[i]
    
    if (aa1 === aa2) {
      totalScore += 1.0 // Exact match
    } else {
      // Combined similarity score
      const blosumScore = calculateBLOSUMSimilarity(aa1, aa2)
      const physicoScore = calculatePhysicochemicalSimilarity(aa1, aa2)
      const combinedScore = (blosumScore + physicoScore) / 2
      totalScore += combinedScore
    }
  }
  
  return totalScore / seq1.length
}

// Calculate statistical significance using background model
export function calculateSignificance(score: number, backgroundScores: number[]): number {
  if (backgroundScores.length === 0) return 0
  
  const mean = backgroundScores.reduce((a, b) => a + b, 0) / backgroundScores.length
  const variance = backgroundScores.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / backgroundScores.length
  const stdDev = Math.sqrt(variance)
  
  if (stdDev === 0) return 0
  
  const zScore = (score - mean) / stdDev
  // Convert to p-value (simplified)
  return Math.exp(-zScore * zScore / 2) / Math.sqrt(2 * Math.PI)
}

// Generate background scores for statistical testing
export function generateBackgroundScores(sequence: string, motifLength: number, numSamples: number = 1000): number[] {
  const scores: number[] = []
  const maxStart = sequence.length - motifLength
  
  for (let i = 0; i < numSamples; i++) {
    const start = Math.floor(Math.random() * maxStart)
    const subsequence = sequence.substring(start, start + motifLength)
    
    // Calculate score for random subsequence
    const score = calculateMotifScore(subsequence, 'ATP_BINDING') // Example motif
    scores.push(score)
  }
  
  return scores
}
