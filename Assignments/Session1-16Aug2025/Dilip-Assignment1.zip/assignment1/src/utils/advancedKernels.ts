import { ProteinSequence, KernelConfig, ActivationMap, ActivationPosition, Motif } from '../types'
import { 
  createAminoAcidEmbedding, 
  calculateBLOSUMSimilarity, 
  calculatePhysicochemicalSimilarity,
  calculateMotifScore,
  calculateEnhancedSimilarity,
  calculateSignificance,
  generateBackgroundScores
} from './advancedEmbeddings'

// Known motif patterns from literature (PROSITE, Pfam, etc.)
export const knownMotifPatterns = {
  'ATP_BINDING': {
    pattern: 'GXGXXG',
    description: 'ATP binding motif (P-loop)',
    references: ['PROSITE PS00017', 'Pfam PF00071'],
    pssm: [
      { 'G': 0.85, 'A': 0.10, 'S': 0.05 },
      { 'X': 1.0 }, // Any amino acid
      { 'G': 0.80, 'A': 0.15, 'S': 0.05 },
      { 'X': 1.0 },
      { 'X': 1.0 },
      { 'G': 0.75, 'A': 0.20, 'S': 0.05 }
    ],
    significance: 0.001 // p-value threshold
  },
  'ZINC_FINGER_C2H2': {
    pattern: 'CX2-4CX3FX5LX2HX3-5H',
    description: 'C2H2 zinc finger domain',
    references: ['PROSITE PS00028', 'Pfam PF00096'],
    pssm: [
      { 'C': 0.95, 'S': 0.05 },
      { 'X': 1.0 },
      { 'X': 1.0 },
      { 'C': 0.95, 'S': 0.05 },
      { 'X': 1.0 },
      { 'X': 1.0 },
      { 'X': 1.0 },
      { 'F': 0.80, 'Y': 0.15, 'W': 0.05 },
      { 'X': 1.0 },
      { 'X': 1.0 },
      { 'X': 1.0 },
      { 'X': 1.0 },
      { 'X': 1.0 },
      { 'L': 0.70, 'I': 0.20, 'V': 0.10 },
      { 'X': 1.0 },
      { 'X': 1.0 },
      { 'H': 0.90, 'N': 0.10 },
      { 'X': 1.0 },
      { 'X': 1.0 },
      { 'X': 1.0 },
      { 'H': 0.90, 'N': 0.10 }
    ],
    significance: 0.001
  },
  'SIGNAL_PEPTIDE': {
    pattern: 'M[ACDEFGHIKLMNPQRSTVWY]{15,35}',
    description: 'Signal peptide cleavage site',
    references: ['SignalP', 'PROSITE PS00013'],
    pssm: [
      { 'M': 0.90, 'A': 0.10 },
      { 'A': 0.25, 'L': 0.20, 'V': 0.15, 'I': 0.15, 'F': 0.10, 'M': 0.10, 'G': 0.05 },
      { 'L': 0.25, 'A': 0.20, 'V': 0.15, 'I': 0.15, 'F': 0.10, 'M': 0.10, 'G': 0.05 },
      { 'L': 0.25, 'A': 0.20, 'V': 0.15, 'I': 0.15, 'F': 0.10, 'M': 0.10, 'G': 0.05 },
      { 'L': 0.25, 'A': 0.20, 'V': 0.15, 'I': 0.15, 'F': 0.10, 'M': 0.10, 'G': 0.05 },
      { 'L': 0.25, 'A': 0.20, 'V': 0.15, 'I': 0.15, 'F': 0.10, 'M': 0.10, 'G': 0.05 }
    ],
    significance: 0.01
  },
  'CATALYTIC_TRIAD': {
    pattern: 'H[ACDEFGHIKLMNPQRSTVWY]{30,50}D[ACDEFGHIKLMNPQRSTVWY]{30,50}S',
    description: 'Serine protease catalytic triad',
    references: ['PROSITE PS00134', 'Pfam PF00089'],
    pssm: [
      { 'H': 0.95, 'N': 0.05 },
      { 'X': 1.0 },
      { 'D': 0.95, 'E': 0.05 },
      { 'X': 1.0 },
      { 'S': 0.95, 'T': 0.05 }
    ],
    significance: 0.001
  }
}

// Advanced kernel configuration based on learned patterns
export const advancedKernelConfig: KernelConfig = {
  width: 6,
  stride: 1,
  numKernels: 4,
  weights: [
    // Kernel 1: ATP binding motif detector
    [0.8, 0.2, 0.8, 0.2, 0.2, 0.8], // GXGXXG pattern
    // Kernel 2: Zinc finger detector
    [0.9, 0.1, 0.1, 0.9, 0.1, 0.1, 0.1, 0.8, 0.1, 0.1, 0.1, 0.1, 0.1, 0.7, 0.1, 0.1, 0.9, 0.1, 0.1, 0.1, 0.9], // C2H2 pattern
    // Kernel 3: Signal peptide detector
    [0.9, 0.3, 0.3, 0.3, 0.3, 0.3], // Hydrophobic pattern
    // Kernel 4: Catalytic site detector
    [0.9, 0.1, 0.9, 0.1, 0.9] // HDS pattern
  ]
}

// Enhanced activation map generation with statistical significance
export function generateAdvancedActivationMap(sequence: ProteinSequence, config: KernelConfig): ActivationMap {
  const positions: ActivationPosition[] = []
  const sequenceLength = sequence.sequence.length
  const maxPosition = sequenceLength - config.width + 1
  
  let maxActivation = 0
  let minActivation = Infinity

  // Generate background scores for statistical testing
  const backgroundScores = generateBackgroundScores(sequence.sequence, config.width)

  for (let pos = 0; pos < maxPosition; pos += config.stride) {
    const subsequence = sequence.sequence.substring(pos, pos + config.width)
    const activations: number[] = []
    const significances: number[] = []

    // Calculate activation for each kernel
    for (let kernelId = 0; kernelId < config.numKernels; kernelId++) {
      const kernelWeights = config.weights[kernelId]
      let activation = 0

      // Enhanced convolution operation
      for (let i = 0; i < Math.min(config.width, subsequence.length); i++) {
        const aminoAcid = subsequence[i]
        const weight = kernelWeights[i] || 0.5
        
        // Create enhanced embedding
        const embedding = createAminoAcidEmbedding(aminoAcid, pos + i, subsequence)
        
        // Calculate multiple similarity measures
        const blosumSimilarity = calculateBLOSUMSimilarity(aminoAcid, getPreferredAminoAcid(kernelId, i))
        const physicoSimilarity = calculatePhysicochemicalSimilarity(aminoAcid, getPreferredAminoAcid(kernelId, i))
        
        // Combined activation score
        const baseActivation = weight * 0.4
        const similarityActivation = (blosumSimilarity + physicoSimilarity) * 0.3
        const embeddingActivation = embedding.reduce((sum, val) => sum + val, 0) / embedding.length * 0.3
        
        activation += baseActivation + similarityActivation + embeddingActivation
      }

      // Apply ReLU-like activation
      activation = Math.max(0, activation)
      activations.push(activation)

      // Calculate statistical significance
      const significance = calculateSignificance(activation, backgroundScores)
      significances.push(significance)

      // Update min/max
      maxActivation = Math.max(maxActivation, activation)
      minActivation = Math.min(minActivation, activation)
    }

    // Enhanced motif matching with statistical significance
    const matchedMotifs = findAdvancedMatchedMotifs(pos, subsequence, sequence.knownMotifs || [], significances)

    positions.push({
      position: pos,
      activations,
      subsequence,
      matchedMotifs,
      significances
    })
  }

  return {
    positions,
    maxActivation,
    minActivation
  }
}

// Get preferred amino acid for each kernel position based on known patterns
function getPreferredAminoAcid(kernelId: number, position: number): string {
  const patterns = {
    0: ['G', 'X', 'G', 'X', 'X', 'G'], // ATP binding
    1: ['C', 'X', 'X', 'C', 'X', 'X', 'X', 'F', 'X', 'X', 'X', 'X', 'X', 'L', 'X', 'X', 'H', 'X', 'X', 'X', 'H'], // Zinc finger
    2: ['M', 'L', 'L', 'L', 'L', 'L'], // Signal peptide
    3: ['H', 'X', 'D', 'X', 'S'] // Catalytic triad
  }
  
  const pattern = patterns[kernelId as keyof typeof patterns] || []
  return pattern[position] || 'X'
}

// Enhanced motif matching with statistical significance
function findAdvancedMatchedMotifs(
  position: number, 
  subsequence: string, 
  knownMotifs: Motif[], 
  significances: number[]
): Motif[] {
  const matchedMotifs: Motif[] = []
  
  // Check known motifs with enhanced similarity
  knownMotifs.forEach(motif => {
    const motifStart = motif.start
    const motifEnd = motif.end
    const motifSequence = motif.sequence
    
    // Check if this position overlaps with a known motif
    const overlapStart = Math.max(position, motifStart)
    const overlapEnd = Math.min(position + subsequence.length, motifEnd)
    
    if (overlapStart < overlapEnd) {
      const overlapLength = overlapEnd - overlapStart
      const motifOverlap = motifSequence.substring(
        Math.max(0, position - motifStart),
        Math.max(0, position - motifStart) + overlapLength
      )
      const subOverlap = subsequence.substring(
        Math.max(0, motifStart - position),
        Math.max(0, motifStart - position) + overlapLength
      )
      
      const similarity = calculateEnhancedSimilarity(motifOverlap, subOverlap)
      
      // Use statistical significance for threshold
      const avgSignificance = significances.reduce((a, b) => a + b, 0) / significances.length
      const threshold = 0.7 + (avgSignificance * 0.2) // Adjust threshold based on significance
      
      if (similarity > threshold) {
        matchedMotifs.push({
          ...motif,
          confidence: similarity,
          pValue: avgSignificance
        })
      }
    }
  })
  
  // Check against known motif patterns
  Object.entries(knownMotifPatterns).forEach(([motifType, motifInfo]) => {
    if (subsequence.length >= motifInfo.pssm.length) {
      const score = calculateMotifScore(subsequence.substring(0, motifInfo.pssm.length), motifType)
      const significance = calculateSignificance(score, generateBackgroundScores(subsequence, motifInfo.pssm.length))
      
      if (significance < motifInfo.significance) {
        matchedMotifs.push({
          name: motifInfo.description,
          start: position,
          end: position + motifInfo.pssm.length,
          sequence: subsequence.substring(0, motifInfo.pssm.length),
          confidence: score,
          pValue: significance,
          type: 'pattern',
          references: motifInfo.references
        })
      }
    }
  })
  
  return matchedMotifs
}

// Calculate motif enrichment score
export function calculateMotifEnrichment(sequence: string, motifPattern: string): number {
  const motifLength = motifPattern.length
  const motifCount = countMotifOccurrences(sequence, motifPattern)
  const expectedCount = calculateExpectedMotifCount(sequence, motifPattern)
  
  if (expectedCount === 0) return 0
  
  return motifCount / expectedCount
}

// Count motif occurrences in sequence
function countMotifOccurrences(sequence: string, motifPattern: string): number {
  let count = 0
  const pattern = motifPattern.replace(/X/g, '.') // Convert X to regex wildcard
  
  for (let i = 0; i <= sequence.length - motifPattern.length; i++) {
    const subsequence = sequence.substring(i, i + motifPattern.length)
    if (matchesPattern(subsequence, motifPattern)) {
      count++
    }
  }
  
  return count
}

// Check if subsequence matches pattern
function matchesPattern(subsequence: string, pattern: string): boolean {
  if (subsequence.length !== pattern.length) return false
  
  for (let i = 0; i < pattern.length; i++) {
    if (pattern[i] !== 'X' && pattern[i] !== subsequence[i]) {
      return false
    }
  }
  
  return true
}

// Calculate expected motif count based on amino acid frequencies
function calculateExpectedMotifCount(sequence: string, motifPattern: string): number {
  const aaFrequencies = calculateAminoAcidFrequencies(sequence)
  let expectedProbability = 1
  
  for (let i = 0; i < motifPattern.length; i++) {
    const aa = motifPattern[i]
    if (aa === 'X') {
      expectedProbability *= 1 // Any amino acid
    } else {
      expectedProbability *= aaFrequencies[aa] || 0.05
    }
  }
  
  return expectedProbability * (sequence.length - motifPattern.length + 1)
}

// Calculate amino acid frequencies in sequence
function calculateAminoAcidFrequencies(sequence: string): { [key: string]: number } {
  const frequencies: { [key: string]: number } = {}
  const length = sequence.length
  
  for (let i = 0; i < length; i++) {
    const aa = sequence[i]
    frequencies[aa] = (frequencies[aa] || 0) + 1
  }
  
  // Normalize
  Object.keys(frequencies).forEach(aa => {
    frequencies[aa] = frequencies[aa] / length
  })
  
  return frequencies
}

// Generate comprehensive motif report
export function generateMotifReport(sequence: ProteinSequence, activationMap: ActivationMap): any {
  const report = {
    sequence: sequence.name,
    length: sequence.sequence.length,
    motifs: [] as any[],
    statistics: {
      totalHighActivations: 0,
      significantMotifs: 0,
      averageActivation: 0,
      motifDensity: 0
    }
  }
  
  // Collect all significant motifs
  const allMotifs = new Map<string, any>()
  
  activationMap.positions.forEach(pos => {
    pos.matchedMotifs.forEach(motif => {
      const key = `${motif.name}_${motif.start}_${motif.end}`
      if (!allMotifs.has(key)) {
        allMotifs.set(key, {
          ...motif,
          occurrences: 1,
          positions: [pos.position]
        })
      } else {
        const existing = allMotifs.get(key)!
        existing.occurrences++
        existing.positions.push(pos.position)
      }
    })
  })
  
  report.motifs = Array.from(allMotifs.values())
  report.statistics.totalHighActivations = activationMap.positions.filter(
    pos => pos.activations.some(act => act > activationMap.maxActivation * 0.5)
  ).length
  report.statistics.significantMotifs = report.motifs.filter(m => m.pValue < 0.05).length
  report.statistics.averageActivation = activationMap.positions.reduce(
    (sum, pos) => sum + pos.activations.reduce((a, b) => a + b, 0) / pos.activations.length, 0
  ) / activationMap.positions.length
  report.statistics.motifDensity = report.motifs.length / sequence.sequence.length * 1000 // per 1000 residues
  
  return report
}
