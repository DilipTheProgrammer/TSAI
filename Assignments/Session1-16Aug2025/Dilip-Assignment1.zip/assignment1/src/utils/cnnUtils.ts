import { ProteinSequence, KernelConfig, ActivationMap, ActivationPosition, Motif } from '../types'

// Amino acid encoding (one-hot encoding)
const aminoAcidEncoding: { [key: string]: number[] } = {
  'A': [1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
  'R': [0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
  'N': [0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
  'D': [0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
  'C': [0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
  'E': [0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
  'Q': [0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0],
  'G': [0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0],
  'H': [0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0],
  'I': [0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0],
  'L': [0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0],
  'K': [0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0],
  'M': [0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0],
  'F': [0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0],
  'P': [0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0],
  'S': [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0],
  'T': [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0],
  'W': [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0],
  'Y': [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0],
  'V': [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1],
}

// Simple amino acid similarity matrix (simplified)
const aminoAcidSimilarity: { [key: string]: { [key: string]: number } } = {
  'A': { 'A': 1.0, 'G': 0.8, 'V': 0.7, 'L': 0.6, 'I': 0.6 },
  'R': { 'R': 1.0, 'K': 0.8, 'H': 0.6, 'Q': 0.5 },
  'N': { 'N': 1.0, 'D': 0.8, 'Q': 0.7, 'S': 0.6 },
  'D': { 'D': 1.0, 'E': 0.8, 'N': 0.8, 'Q': 0.6 },
  'C': { 'C': 1.0, 'S': 0.6, 'T': 0.5 },
  'E': { 'E': 1.0, 'D': 0.8, 'Q': 0.7, 'K': 0.6 },
  'Q': { 'Q': 1.0, 'E': 0.7, 'N': 0.7, 'R': 0.5 },
  'G': { 'G': 1.0, 'A': 0.8, 'S': 0.6 },
  'H': { 'H': 1.0, 'R': 0.6, 'K': 0.6, 'Y': 0.5 },
  'I': { 'I': 1.0, 'L': 0.8, 'V': 0.8, 'M': 0.7 },
  'L': { 'L': 1.0, 'I': 0.8, 'V': 0.7, 'M': 0.7 },
  'K': { 'K': 1.0, 'R': 0.8, 'Q': 0.6, 'E': 0.6 },
  'M': { 'M': 1.0, 'L': 0.7, 'I': 0.7, 'V': 0.6 },
  'F': { 'F': 1.0, 'Y': 0.8, 'W': 0.7, 'L': 0.6 },
  'P': { 'P': 1.0, 'A': 0.5, 'G': 0.5 },
  'S': { 'S': 1.0, 'T': 0.8, 'A': 0.6, 'G': 0.6 },
  'T': { 'T': 1.0, 'S': 0.8, 'A': 0.6, 'V': 0.6 },
  'W': { 'W': 1.0, 'F': 0.7, 'Y': 0.6 },
  'Y': { 'Y': 1.0, 'F': 0.8, 'H': 0.5, 'W': 0.6 },
  'V': { 'V': 1.0, 'I': 0.8, 'L': 0.7, 'A': 0.7 },
}

export function generateActivationMap(sequence: ProteinSequence, config: KernelConfig): ActivationMap {
  const positions: ActivationPosition[] = []
  const sequenceLength = sequence.sequence.length
  const maxPosition = sequenceLength - config.width + 1
  
  let maxActivation = 0
  let minActivation = Infinity

  for (let pos = 0; pos < maxPosition; pos += config.stride) {
    const subsequence = sequence.sequence.substring(pos, pos + config.width)
    const activations: number[] = []

    // Calculate activation for each kernel
    for (let kernelId = 0; kernelId < config.numKernels; kernelId++) {
      const kernelWeights = config.weights[kernelId]
      let activation = 0

      // Convolution operation
      for (let i = 0; i < config.width; i++) {
        const aminoAcid = subsequence[i]
        const weight = kernelWeights[i]
        
        // Calculate similarity-based activation
        const baseActivation = weight * 0.5 // Base activation from weight
        const similarityBonus = calculateAminoAcidSimilarity(aminoAcid, kernelId, config)
        activation += baseActivation + similarityBonus
      }

      // Apply ReLU-like activation
      activation = Math.max(0, activation)
      activations.push(activation)

      // Update min/max
      maxActivation = Math.max(maxActivation, activation)
      minActivation = Math.min(minActivation, activation)
    }

    // Find matched motifs for this position
    const matchedMotifs = findMatchedMotifs(pos, subsequence, sequence.knownMotifs || [])

    positions.push({
      position: pos,
      activations,
      subsequence,
      matchedMotifs
    })
  }

  return {
    positions,
    maxActivation,
    minActivation
  }
}

function calculateAminoAcidSimilarity(aminoAcid: string, kernelId: number, config: KernelConfig): number {
  // Simplified similarity calculation based on kernel preferences
  const kernelWeights = config.weights[kernelId]
  
  // Define preferred amino acids for each kernel (simplified)
  const kernelPreferences = [
    ['G', 'A', 'S'], // Kernel 1 prefers small amino acids
    ['R', 'K', 'H'], // Kernel 2 prefers basic amino acids
    ['D', 'E', 'N']  // Kernel 3 prefers acidic amino acids
  ]

  const preferences = kernelPreferences[kernelId] || []
  if (preferences.includes(aminoAcid)) {
    return 0.3 // Bonus for preferred amino acids
  }

  return 0.0
}

function findMatchedMotifs(position: number, subsequence: string, knownMotifs: Motif[]): Motif[] {
  return knownMotifs.filter(motif => {
    const motifStart = motif.start
    const motifEnd = motif.end
    const motifSequence = motif.sequence
    
    // Check if this position overlaps with a known motif
    const overlapStart = Math.max(position, motifStart)
    const overlapEnd = Math.min(position + subsequence.length, motifEnd)
    
    if (overlapStart < overlapEnd) {
      // Calculate overlap similarity
      const overlapLength = overlapEnd - overlapStart
      const motifOverlap = motifSequence.substring(
        Math.max(0, position - motifStart),
        Math.max(0, position - motifStart) + overlapLength
      )
      const subOverlap = subsequence.substring(
        Math.max(0, motifStart - position),
        Math.max(0, motifStart - position) + overlapLength
      )
      
      return calculateSequenceSimilarity(motifOverlap, subOverlap) > 0.7
    }
    
    return false
  })
}

function calculateSequenceSimilarity(seq1: string, seq2: string): number {
  if (seq1.length !== seq2.length || seq1.length === 0) return 0
  
  let matches = 0
  for (let i = 0; i < seq1.length; i++) {
    const aa1 = seq1[i]
    const aa2 = seq2[i]
    
    if (aa1 === aa2) {
      matches++
    } else if (aminoAcidSimilarity[aa1]?.[aa2] > 0.6) {
      matches += 0.5
    }
  }
  
  return matches / seq1.length
}

export function generateSequenceLogo(positions: ActivationPosition[], kernelId: number, threshold: number = 0.5): any[] {
  const highActivationPositions = positions.filter(pos => pos.activations[kernelId] > threshold)
  
  if (highActivationPositions.length === 0) return []

  const logo = []
  const width = highActivationPositions[0].subsequence.length

  for (let i = 0; i < width; i++) {
    const aminoAcidCounts: { [key: string]: number } = {}
    let totalCount = 0

    highActivationPositions.forEach(pos => {
      const aa = pos.subsequence[i]
      aminoAcidCounts[aa] = (aminoAcidCounts[aa] || 0) + 1
      totalCount++
    })

    // Calculate frequencies
    const frequencies: { [key: string]: number } = {}
    Object.keys(aminoAcidCounts).forEach(aa => {
      frequencies[aa] = aminoAcidCounts[aa] / totalCount
    })

    logo.push({
      position: i,
      aminoAcids: frequencies,
      height: Math.max(...Object.values(frequencies))
    })
  }

  return logo
}

