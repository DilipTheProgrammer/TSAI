import { DemoSequence } from '../types'

export const demoSequences: DemoSequence[] = [
  {
    name: "Kinase Domain",
    sequence: "MNGTEGPNFYVPFSNATGVVRSPFEYPQYYLAEPWQFSMLAAYMFLLIVLGFPINFLTLYVTVQHKKLRTPLNYILLNLAVADLFMVLGGFTSTLYTSLHGYFVFGPTGCNLEGFFATLGGEIALWSLVVLAIERYVVVCKPMSNFRFGENHAIMGVAFTWVMALACAAPPLAGWSRYIPEGLQCSCGIDYYTLKPEVNNESFVIYMFVVHFTIPMIIIFFCYGQLVFTVKEAAAQQQESATTQKAEKEVTRMVIIMVIAFLICWVPYASVAFYIFTHQGSNFGPIFMTIPAFFAKSAAIYNPVIYIMMNKQFRNCMLTTICCGKNPLGDDEASATVSKTETSQVAPA",
    description: "Protein kinase domain with catalytic activity",
    category: "kinase",
    knownMotifs: [
      { name: "ATP binding site", start: 45, end: 55, sequence: "GXGXXG", confidence: 0.9, type: "motif" },
      { name: "Catalytic loop", start: 165, end: 175, sequence: "HRDLKPEN", confidence: 0.8, type: "motif" }
    ]
  },
  {
    name: "Zinc Finger",
    sequence: "MADPYKCSECGKSFSQKSNLKRHQRTHTGEKPYKCPECGKSFSRKSNLKRHMRTHTGEK",
    description: "C2H2 zinc finger transcription factor",
    category: "zinc-finger",
    knownMotifs: [
      { name: "Zinc finger 1", start: 8, end: 28, sequence: "CSECGKSFSQKSNLKRHQRTH", confidence: 0.95, type: "domain" },
      { name: "Zinc finger 2", start: 38, end: 58, sequence: "CPECGKSFSRKSNLKRHMRTH", confidence: 0.95, type: "domain" }
    ]
  },
  {
    name: "Transmembrane Protein",
    sequence: "MALWMRLLPLLALLALWGPDPAAAFVNQHLCGSHLVEALYLVCGERGFFYTPKT",
    description: "Transmembrane receptor protein",
    category: "transmembrane",
    knownMotifs: [
      { name: "Signal peptide", start: 1, end: 24, sequence: "MALWMRLLPLLALLALWGPDPAA", confidence: 0.85, type: "signal" },
      { name: "Transmembrane domain", start: 25, end: 45, sequence: "AFVNQHLCGSHLVEALYLVCG", confidence: 0.9, type: "domain" }
    ]
  }
]

