export interface ProteinSequence {
  name: string
  sequence: string
  description?: string
  knownMotifs?: Motif[]
  category?: string
}

export interface Motif {
  name: string
  start: number
  end: number
  sequence: string
  confidence: number
  type?: string
  pValue?: number // Statistical significance
  references?: string[] // Literature references
}

export interface KernelConfig {
  width: number
  stride: number
  numKernels: number
  weights: number[][]
  useAdvancedEmbeddings?: boolean // Flag for advanced embeddings
  statisticalTesting?: boolean // Flag for statistical significance
}

export interface ActivationPosition {
  position: number
  activations: number[]
  subsequence: string
  matchedMotifs: Motif[]
  significances?: number[] // Statistical significance for each kernel
}

export interface ActivationMap {
  positions: ActivationPosition[]
  maxActivation: number
  minActivation: number
}

export interface SequenceLogo {
  position: number
  aminoAcids: { [key: string]: number }
  height: number
}

export interface KernelVisualization {
  kernelId: number
  weights: number[]
  preferredSequence: string
  activationPattern: number[]
  discoveredMotifs: Motif[]
}

export interface DemoSequence {
  name: string
  sequence: string
  description: string
  category: string
  knownMotifs: Motif[]
}

// Advanced types for enhanced functionality
export interface AminoAcidEmbedding {
  aminoAcid: string
  position: number
  features: number[] // [hydrophobicity, charge, polarity, size, flexibility, pos_encoding, context]
  physicochemical: {
    hydrophobicity: number
    charge: number
    polarity: number
    size: number
    flexibility: number
  }
}

export interface MotifPattern {
  name: string
  pattern: string
  description: string
  references: string[]
  pssm: { [key: string]: number }[] // Position-specific scoring matrix
  significance: number // p-value threshold
}

export interface StatisticalTest {
  score: number
  pValue: number
  zScore: number
  significance: 'high' | 'medium' | 'low' | 'none'
}

export interface MotifReport {
  sequence: string
  length: number
  motifs: EnhancedMotif[]
  statistics: {
    totalHighActivations: number
    significantMotifs: number
    averageActivation: number
    motifDensity: number // motifs per 1000 residues
  }
  enrichment: {
    [motifType: string]: number // Enrichment scores
  }
}

export interface EnhancedMotif extends Motif {
  occurrences: number
  positions: number[]
  enrichment: number
  statisticalTest: StatisticalTest
  motifType: string
}

export interface BackgroundModel {
  aminoAcidFrequencies: { [key: string]: number }
  motifFrequencies: { [key: string]: number }
  sequenceLength: number
  numSamples: number
}

export interface AdvancedKernelConfig extends KernelConfig {
  motifPatterns: MotifPattern[]
  backgroundModel: BackgroundModel
  significanceThreshold: number
  usePositionEncoding: boolean
  useContextFeatures: boolean
}

