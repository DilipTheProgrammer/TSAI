import React from 'react'
import { motion } from 'framer-motion'
import { Settings, Play, Pause, SkipBack, SkipForward, Sliders } from 'lucide-react'
import { KernelConfig } from '../types'

interface SidebarProps {
  kernelConfig: KernelConfig
  onKernelConfigChange: (config: Partial<KernelConfig>) => void
  selectedKernel: number
  onKernelSelect: (kernelId: number) => void
  currentStep: number
  onStepForward: () => void
  onStepBackward: () => void
  onAutoPlay: () => void
  isAnimating: boolean
  totalSteps: number
}

const Sidebar: React.FC<SidebarProps> = ({
  kernelConfig,
  onKernelConfigChange,
  selectedKernel,
  onKernelSelect,
  currentStep,
  onStepForward,
  onStepBackward,
  onAutoPlay,
  isAnimating,
  totalSteps
}) => {
  return (
    <div className="space-y-6">
      {/* Kernel Configuration */}
      <div className="card">
        <div className="flex items-center mb-4">
          <Settings className="w-5 h-5 text-gray-500 mr-2" />
          <h3 className="text-lg font-medium text-gray-800">Kernel Settings</h3>
        </div>

        {/* Kernel Width */}
        <div className="mb-4">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Kernel Width: {kernelConfig.width}
          </label>
          <input
            type="range"
            min="3"
            max="10"
            value={kernelConfig.width}
            onChange={(e) => onKernelConfigChange({ width: parseInt(e.target.value) })}
            className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer slider"
          />
          <div className="flex justify-between text-xs text-gray-500 mt-1">
            <span>3</span>
            <span>10</span>
          </div>
        </div>

        {/* Stride */}
        <div className="mb-4">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Stride: {kernelConfig.stride}
          </label>
          <input
            type="range"
            min="1"
            max="5"
            value={kernelConfig.stride}
            onChange={(e) => onKernelConfigChange({ stride: parseInt(e.target.value) })}
            className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer slider"
          />
          <div className="flex justify-between text-xs text-gray-500 mt-1">
            <span>1</span>
            <span>5</span>
          </div>
        </div>

        {/* Number of Kernels */}
        <div className="mb-4">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Number of Kernels: {kernelConfig.numKernels}
          </label>
          <input
            type="range"
            min="1"
            max="5"
            value={kernelConfig.numKernels}
            onChange={(e) => onKernelConfigChange({ numKernels: parseInt(e.target.value) })}
            className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer slider"
          />
          <div className="flex justify-between text-xs text-gray-500 mt-1">
            <span>1</span>
            <span>5</span>
          </div>
        </div>
      </div>

      {/* Kernel Selection */}
      <div className="card">
        <div className="flex items-center mb-4">
          <Sliders className="w-5 h-5 text-gray-500 mr-2" />
          <h3 className="text-lg font-medium text-gray-800">Select Kernel</h3>
        </div>

        <div className="space-y-2">
          {Array.from({ length: kernelConfig.numKernels }, (_, i) => (
            <button
              key={i}
              onClick={() => onKernelSelect(i)}
              className={`w-full p-3 rounded-lg border transition-colors ${
                selectedKernel === i
                  ? 'border-primary-500 bg-primary-50 text-primary-700'
                  : 'border-gray-200 hover:border-gray-300 text-gray-700'
              }`}
            >
              <div className="font-medium">Kernel {i + 1}</div>
              <div className="text-sm text-gray-500 mt-1">
                Weights: [{kernelConfig.weights[i]?.slice(0, 3).map(w => w.toFixed(1)).join(', ')}...]
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Animation Controls */}
      <div className="card">
        <div className="flex items-center mb-4">
          <Play className="w-5 h-5 text-gray-500 mr-2" />
          <h3 className="text-lg font-medium text-gray-800">Animation Controls</h3>
        </div>

        <div className="space-y-4">
          {/* Progress Bar */}
          <div>
            <div className="flex justify-between text-sm text-gray-600 mb-2">
              <span>Step {currentStep + 1} of {totalSteps}</span>
              <span>{Math.round(((currentStep + 1) / totalSteps) * 100)}%</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <motion.div
                className="bg-primary-600 h-2 rounded-full"
                initial={{ width: 0 }}
                animate={{ width: `${((currentStep + 1) / totalSteps) * 100}%` }}
                transition={{ duration: 0.3 }}
              />
            </div>
          </div>

          {/* Control Buttons */}
          <div className="flex space-x-2">
            <button
              onClick={onStepBackward}
              disabled={currentStep === 0}
              className="flex-1 btn-secondary disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <SkipBack className="w-4 h-4" />
            </button>
            
            <button
              onClick={onAutoPlay}
              className="flex-1 btn-primary"
            >
              {isAnimating ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
            </button>
            
            <button
              onClick={onStepForward}
              disabled={currentStep >= totalSteps - 1}
              className="flex-1 btn-secondary disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <SkipForward className="w-4 h-4" />
            </button>
          </div>

          {/* Step Info */}
          <div className="text-center text-sm text-gray-600">
            {isAnimating ? 'Auto-playing...' : 'Manual mode'}
          </div>
        </div>
      </div>

      {/* Help Section */}
      <div className="card">
        <h3 className="text-lg font-medium text-gray-800 mb-3">How it Works</h3>
        <div className="space-y-3 text-sm text-gray-600">
          <div>
            <strong>Kernel Width:</strong> Size of the sliding window that scans the sequence
          </div>
          <div>
            <strong>Stride:</strong> How many positions the kernel moves at each step
          </div>
          <div>
            <strong>Activation:</strong> How strongly the kernel responds to each subsequence
          </div>
          <div>
            <strong>Motifs:</strong> Recurring patterns that kernels learn to recognize
          </div>
        </div>
      </div>
    </div>
  )
}

export default Sidebar

