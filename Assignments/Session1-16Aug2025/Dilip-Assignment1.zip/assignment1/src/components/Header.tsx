import React from 'react'
import { motion } from 'framer-motion'
import { Dna, Brain, Zap } from 'lucide-react'

const Header: React.FC = () => {
  return (
    <motion.header 
      className="bg-gradient-to-r from-primary-600 to-primary-800 text-white shadow-lg"
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <div className="container mx-auto px-4 py-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <Dna className="w-8 h-8" />
              <Brain className="w-8 h-8" />
              <Zap className="w-8 h-8" />
            </div>
            <div>
              <h1 className="text-2xl font-bold">CNN Kernel Visualizer</h1>
              <p className="text-primary-100 text-sm">Interactive Protein Motif Discovery</p>
            </div>
          </div>
          
          <div className="hidden md:flex items-center space-x-6 text-sm">
            <a href="#about" className="hover:text-primary-200 transition-colors">
              About
            </a>
            <a href="#tutorial" className="hover:text-primary-200 transition-colors">
              Tutorial
            </a>
            <a href="#examples" className="hover:text-primary-200 transition-colors">
              Examples
            </a>
          </div>
        </div>
        
        <motion.div 
          className="mt-4 text-center"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3, duration: 0.5 }}
        >
          <p className="text-primary-100 max-w-3xl mx-auto">
            Explore how Convolutional Neural Networks detect protein motifs and domains through 
            interactive visualizations. Learn the inner workings of CNN kernels as they scan 
            protein sequences for biological patterns.
          </p>
        </motion.div>
      </div>
    </motion.header>
  )
}

export default Header

