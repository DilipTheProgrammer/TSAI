import React from 'react'
import { motion } from 'framer-motion'
import { BarChart3, Download, Share2, Info, TrendingUp, Target, AlertCircle } from 'lucide-react'
import { ProteinSequence, KernelConfig, ActivationMap } from '../types'
import { generateSequenceLogo } from '../utils/cnnUtils'

interface MotifDisplayProps {
  sequence: ProteinSequence
  activationMap: ActivationMap
  kernelConfig: KernelConfig
  selectedKernel: number
}

const MotifDisplay: React.FC<MotifDisplayProps> = ({
  sequence,
  activationMap,
  kernelConfig,
  selectedKernel
}) => {
  const sequenceLogo = generateSequenceLogo(activationMap.positions, selectedKernel, activationMap.maxActivation * 0.3)
  const highActivationPositions = activationMap.positions.filter(
    pos => pos.activations[selectedKernel] > activationMap.maxActivation * 0.5
  )

  const getAminoAcidColor = (aa: string) => {
    return `bg-amino-${aa}`
  }

  const exportResults = () => {
    const results = {
      sequence: sequence.name,
      kernel: selectedKernel + 1,
      highActivationPositions: highActivationPositions.map(pos => ({
        position: pos.position + 1,
        subsequence: pos.subsequence,
        activation: pos.activations[selectedKernel],
        matchedMotifs: pos.matchedMotifs
      })),
      sequenceLogo: sequenceLogo
    }

    const blob = new Blob([JSON.stringify(results, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `cnn_results_${sequence.name}_kernel${selectedKernel + 1}.json`
    a.click()
    URL.revokeObjectURL(url)
  }

  return (
    <div className="space-y-6">
      {/* Analysis Summary - Top Priority */}
      <div className="card bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center">
            <TrendingUp className="w-6 h-6 text-blue-600 mr-2" />
            <h3 className="text-xl font-semibold text-blue-900">Analysis Results</h3>
          </div>
          <div className="flex space-x-2">
            <button
              onClick={exportResults}
              className="btn-secondary text-sm"
            >
              <Download className="w-4 h-4 mr-1" />
              Export
            </button>
          </div>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
          <div className="bg-white rounded-lg p-3 text-center border border-blue-200">
            <div className="text-2xl font-bold text-blue-600">
              {highActivationPositions.length}
            </div>
            <div className="text-sm text-blue-700">High Activations</div>
          </div>
          <div className="bg-white rounded-lg p-3 text-center border border-green-200">
            <div className="text-2xl font-bold text-green-600">
              {highActivationPositions.filter(pos => pos.matchedMotifs.length > 0).length}
            </div>
            <div className="text-sm text-green-700">Known Motifs</div>
          </div>
          <div className="bg-white rounded-lg p-3 text-center border border-purple-200">
            <div className="text-2xl font-bold text-purple-600">
              {activationMap.maxActivation.toFixed(3)}
            </div>
            <div className="text-sm text-purple-700">Max Activation</div>
          </div>
          <div className="bg-white rounded-lg p-3 text-center border border-orange-200">
            <div className="text-2xl font-bold text-orange-600">
              {kernelConfig.width}
            </div>
            <div className="text-sm text-orange-700">Kernel Width</div>
          </div>
        </div>

        {/* Quick Insights */}
        <div className="bg-white rounded-lg p-4 border border-blue-200">
          <h4 className="font-medium text-blue-900 mb-2">Quick Insights</h4>
          <div className="text-sm text-blue-800 space-y-1">
            <div>• Kernel {selectedKernel + 1} detected {highActivationPositions.length} potential motif sites</div>
            {highActivationPositions.filter(pos => pos.matchedMotifs.length > 0).length > 0 && (
              <div>• {highActivationPositions.filter(pos => pos.matchedMotifs.length > 0).length} sites match known biological motifs</div>
            )}
            <div>• Analysis completed on {sequence.sequence.length} amino acid sequence</div>
          </div>
        </div>
      </div>

      {/* High Activation Positions */}
      <div className="card">
        <div className="flex items-center mb-4">
          <Target className="w-5 h-5 text-gray-500 mr-2" />
          <h3 className="text-lg font-medium text-gray-800">High Activation Positions</h3>
        </div>

        {highActivationPositions.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {highActivationPositions.slice(0, 9).map((pos, index) => (
              <motion.div
                key={index}
                className="border border-gray-200 rounded-lg p-3 hover:border-primary-300 transition-colors"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-gray-800">
                    Position {pos.position + 1}
                  </span>
                  <span className="text-xs text-gray-500">
                    {pos.activations[selectedKernel].toFixed(3)}
                  </span>
                </div>
                <div className="flex space-x-1 mb-2">
                  {pos.subsequence.split('').map((aa, aaIndex) => (
                    <div
                      key={aaIndex}
                      className={`amino-acid ${getAminoAcidColor(aa)} text-xs`}
                    >
                      {aa}
                    </div>
                  ))}
                </div>
                {pos.matchedMotifs.length > 0 && (
                  <div className="text-xs text-green-600 bg-green-50 px-2 py-1 rounded">
                    ✓ {pos.matchedMotifs.map(m => m.name).join(', ')}
                  </div>
                )}
              </motion.div>
            ))}
          </div>
        ) : (
          <div className="text-center py-8 text-gray-500">
            <AlertCircle className="w-12 h-12 mx-auto mb-2 text-gray-400" />
            <p>No high activation positions found. Try adjusting the kernel parameters.</p>
          </div>
        )}
      </div>

      {/* Sequence Logo */}
      {sequenceLogo.length > 0 && (
        <div className="card">
          <div className="flex items-center mb-4">
            <Info className="w-5 h-5 text-gray-500 mr-2" />
            <h3 className="text-lg font-medium text-gray-800">Sequence Logo</h3>
          </div>

          <div className="space-y-4">
            <p className="text-sm text-gray-600">
              Amino acid frequency at each position for subsequences with high activation
            </p>

            <div className="bg-gray-50 rounded-lg p-4">
              <div className="overflow-x-auto">
                <div className="flex items-end space-x-1 h-32 min-w-max">
                  {sequenceLogo.map((position, index) => (
                    <div key={index} className="flex-1 flex flex-col items-center min-w-[40px]">
                      <div className="w-full bg-white border border-gray-200 rounded-t overflow-hidden">
                        {Object.entries(position.aminoAcids)
                          .sort(([,a], [,b]) => b - a)
                          .map(([aa, freq]) => (
                            <div
                              key={aa}
                              className={`${getAminoAcidColor(aa)} text-center text-xs font-bold`}
                              style={{ height: `${(freq / position.height) * 100}%` }}
                            >
                              {freq > 0.1 ? aa : ''}
                            </div>
                          ))}
                      </div>
                      <div className="text-xs text-gray-500 mt-1">{index + 1}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="text-xs text-gray-500 text-center">
              Position numbers correspond to kernel positions
            </div>
          </div>
        </div>
      )}

      {/* Detailed Summary */}
      <div className="card">
        <h3 className="text-lg font-medium text-gray-800 mb-4">Detailed Summary</h3>
        
        <div className="space-y-3 text-sm">
          <div className="flex justify-between">
            <span className="text-gray-600">Sequence:</span>
            <span className="font-medium">{sequence.name}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-600">Sequence Length:</span>
            <span className="font-medium">{sequence.sequence.length} amino acids</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-600">Selected Kernel:</span>
            <span className="font-medium">Kernel {selectedKernel + 1}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-600">Kernel Width:</span>
            <span className="font-medium">{kernelConfig.width}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-600">High Activation Sites:</span>
            <span className="font-medium">{highActivationPositions.length}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-600">Average Activation:</span>
            <span className="font-medium">
              {(highActivationPositions.reduce((sum, pos) => sum + pos.activations[selectedKernel], 0) / 
                Math.max(highActivationPositions.length, 1)).toFixed(3)}
            </span>
          </div>
        </div>

        <div className="mt-4 p-3 bg-blue-50 border border-blue-200 rounded-lg">
          <div className="text-sm text-blue-800">
            <strong>Interpretation:</strong> Kernel {selectedKernel + 1} has identified{' '}
            {highActivationPositions.length} potential motif sites in the sequence. 
            {highActivationPositions.filter(pos => pos.matchedMotifs.length > 0).length > 0 && (
              <span> Some of these match known biological motifs.</span>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

export default MotifDisplay

