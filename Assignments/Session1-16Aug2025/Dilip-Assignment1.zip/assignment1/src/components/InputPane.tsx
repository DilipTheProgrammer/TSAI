import React, { useState } from 'react'
import { motion } from 'framer-motion'
import { Upload, FileText, Play, Info, AlertCircle } from 'lucide-react'
import { ProteinSequence } from '../types'
import { demoSequences } from '../data/demoSequences'

interface InputPaneProps {
  onSequenceLoad: (sequence: ProteinSequence) => void
  onDemoSequence: (sequenceName: string) => void
  currentSequence: ProteinSequence | null
}

const InputPane: React.FC<InputPaneProps> = ({ onSequenceLoad, onDemoSequence, currentSequence }) => {
  const [inputSequence, setInputSequence] = useState('')
  const [sequenceName, setSequenceName] = useState('')
  const [showDemoOptions, setShowDemoOptions] = useState(false)
  const [error, setError] = useState<string | null>(null)

  // Valid amino acid codes (one-letter)
  const validAminoAcids = new Set('ACDEFGHIKLMNPQRSTVWY')

  const validateAminoAcidSequence = (sequence: string): { isValid: boolean; invalidChars: string[] } => {
    const invalidChars: string[] = []
    const upperSequence = sequence.toUpperCase()
    
    for (let i = 0; i < upperSequence.length; i++) {
      const char = upperSequence[i]
      if (!validAminoAcids.has(char)) {
        invalidChars.push(char)
      }
    }
    
    return {
      isValid: invalidChars.length === 0,
      invalidChars: [...new Set(invalidChars)] // Remove duplicates
    }
  }

  const parseFASTA = (content: string): { name: string; sequence: string; error?: string } => {
    // Normalize line endings and split
    const normalizedContent = content.replace(/\r\n/g, '\n').replace(/\r/g, '\n')
    const lines = normalizedContent.split('\n')
    let name = 'Uploaded Sequence'
    let sequence = ''
    let inSequence = false
    
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i].trim()
      
      // Skip empty lines
      if (!line) continue
      
      // Handle header line (starts with >)
      if (line.startsWith('>')) {
        // If we already have a sequence, this is a new entry (multi-FASTA)
        if (sequence && inSequence) {
          break // Only process the first sequence for now
        }
        
        // Extract header information - take only the first part before any spaces
        const header = line.substring(1).trim()
        const spaceIndex = header.indexOf(' ')
        
        if (spaceIndex > 0) {
          name = header.substring(0, spaceIndex)
        } else {
          name = header
        }
        
        inSequence = true
        continue
      }
      
      // Skip comment lines (start with ;)
      if (line.startsWith(';')) continue
      
      // Process sequence lines
      if (inSequence) {
        // Remove any whitespace and convert to uppercase
        const cleanLine = line.replace(/\s/g, '').toUpperCase()
        
        // Additional safety check: ensure this line doesn't contain header-like content
        if (cleanLine.includes('>') || cleanLine.includes('|') || cleanLine.includes('=') || 
            cleanLine.includes('_') || cleanLine.includes('-') || cleanLine.includes('0') || 
            cleanLine.includes('1') || cleanLine.includes('2') || cleanLine.includes('3') || 
            cleanLine.includes('4') || cleanLine.includes('5') || cleanLine.includes('6') || 
            cleanLine.includes('7') || cleanLine.includes('8') || cleanLine.includes('9')) {
          continue
        }
        
        // Only process lines that contain valid amino acid characters
        const validChars = cleanLine.match(/[ACDEFGHIKLMNPQRSTVWY]/g)
        if (validChars && validChars.length > 0) {
          sequence += cleanLine
        }
      }
    }
    
    // Validate the sequence
    if (!sequence) {
      return { name: '', sequence: '', error: 'No valid sequence found in FASTA file' }
    }
    
    const validation = validateAminoAcidSequence(sequence)
    if (!validation.isValid) {
      return { 
        name, 
        sequence, 
        error: `Invalid amino acid characters found: ${validation.invalidChars.join(', ')}. Valid characters are: ACDEFGHIKLMNPQRSTVWY` 
      }
    }
    
    return { name, sequence }
  }

  const [uniprotId, setUniprotId] = useState('')
  const [isLoadingUniprot, setIsLoadingUniprot] = useState(false)

  const fetchFromUniProt = async (id: string) => {
    setIsLoadingUniprot(true)
    setError(null)
    
    try {
      // Fetch protein information from UniProt API
      const response = await fetch(`https://rest.uniprot.org/uniprotkb/${id.toUpperCase()}`)
      
      if (!response.ok) {
        throw new Error(`Protein not found: ${id}`)
      }
      
      const data = await response.json()
      
      if (!data.sequence || !data.sequence.value) {
        throw new Error('No sequence data found')
      }
      
      const sequence = data.sequence.value
      const name = data.entryName || data.primaryAccession || id
      const description = data.proteinDescription?.recommendedName?.fullName?.value || 
                         data.proteinDescription?.submissionNames?.[0]?.fullName?.value ||
                         data.proteinDescription?.alternativeNames?.[0]?.fullName?.value ||
                         'UniProt protein'
      
      // Validate the sequence
      const validation = validateAminoAcidSequence(sequence)
      if (!validation.isValid) {
        throw new Error(`Invalid amino acid characters found: ${validation.invalidChars.join(', ')}`)
      }
      
      if (sequence.length < 5) {
        throw new Error('Sequence too short. Please provide a sequence with at least 5 amino acids.')
      }
      
      onSequenceLoad({
        name: name,
        sequence: sequence,
        description: `${description} (UniProt: ${id.toUpperCase()})`
      })
      
      setUniprotId('') // Clear the input
      
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Error fetching from UniProt')
    } finally {
      setIsLoadingUniprot(false)
    }
  }

  const handleUniProtSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (uniprotId.trim()) {
      fetchFromUniProt(uniprotId.trim())
    }
  }

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onload = (e) => {
        const content = e.target?.result as string
        
        try {
          const result = parseFASTA(content)
          
          if (result.error) {
            setError(result.error)
            return
          }
          
          if (result.sequence.length < 5) {
            setError('Sequence too short. Please provide a sequence with at least 5 amino acids.')
            return
          }
          
          setError(null)
          onSequenceLoad({
            name: result.name,
            sequence: result.sequence,
            description: `Uploaded from file: ${file.name}`
          })
        } catch (err) {
          setError('Error parsing FASTA file. Please check the file format.')
        }
      }
      
      reader.onerror = () => {
        setError('Error reading file. Please try again.')
      }
      
      reader.readAsText(file)
    }
  }

  const handleManualInput = () => {
    if (!inputSequence.trim()) {
      setError('Please enter a protein sequence.')
      return
    }
    
    // Clean the input sequence
    const cleanSequence = inputSequence.replace(/\s/g, '').toUpperCase()
    
    // Validate the sequence
    const validation = validateAminoAcidSequence(cleanSequence)
    if (!validation.isValid) {
      setError(`Invalid amino acid characters found: ${validation.invalidChars.join(', ')}. Valid characters are: ACDEFGHIKLMNPQRSTVWY`)
      return
    }
    
    if (cleanSequence.length < 5) {
      setError('Sequence too short. Please provide a sequence with at least 5 amino acids.')
      return
    }
    
    setError(null)
    onSequenceLoad({
      name: sequenceName || 'Manual Input',
      sequence: cleanSequence,
      description: 'Manually entered sequence'
    })
  }

  const handleDemoClick = (sequenceName: string) => {
    setError(null)
    onDemoSequence(sequenceName)
    setShowDemoOptions(false)
  }

  return (
    <div className="card">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-semibold text-gray-800">Protein Sequence Input</h2>
        <Info className="w-5 h-5 text-gray-500" />
      </div>

      {/* Error Display */}
      {error && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg"
        >
          <div className="flex items-center">
            <AlertCircle className="w-4 h-4 text-red-500 mr-2" />
            <span className="text-sm text-red-700">{error}</span>
          </div>
        </motion.div>
      )}

      {/* Demo Sequences */}
      <div className="mb-6">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-lg font-medium text-gray-700">Demo Sequences</h3>
          <button
            onClick={() => setShowDemoOptions(!showDemoOptions)}
            className="btn-secondary text-sm"
          >
            {showDemoOptions ? 'Hide' : 'Show'} Examples
          </button>
        </div>

        {showDemoOptions && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="grid grid-cols-1 md:grid-cols-3 gap-3"
          >
            {demoSequences.map((demo) => (
              <motion.button
                key={demo.name}
                onClick={() => handleDemoClick(demo.name)}
                className="p-3 border border-gray-200 rounded-lg hover:border-primary-300 hover:bg-primary-50 transition-colors text-left"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                <div className="font-medium text-gray-800">{demo.name}</div>
                <div className="text-sm text-gray-600 mt-1">{demo.description}</div>
                <div className="text-xs text-gray-500 mt-2">
                  {demo.sequence.length} amino acids
                </div>
              </motion.button>
            ))}
          </motion.div>
        )}
      </div>

             {/* UniProt ID Input */}
       <div className="mb-6">
         <h3 className="text-lg font-medium text-gray-700 mb-3">Fetch from UniProt</h3>
         <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
           <p className="text-sm text-blue-700 mb-3">
             Enter a UniProt ID to fetch protein sequences directly from the UniProt database.
           </p>
           <form onSubmit={handleUniProtSubmit} className="flex gap-2">
             <input
               type="text"
               placeholder="e.g., P01911, DRB1_HUMAN, or sp|P01911|DRB1_HUMAN"
               value={uniprotId}
               onChange={(e) => setUniprotId(e.target.value)}
               className="input-field flex-1"
               disabled={isLoadingUniprot}
             />
             <button
               type="submit"
               disabled={!uniprotId.trim() || isLoadingUniprot}
               className="btn-primary disabled:opacity-50 disabled:cursor-not-allowed"
             >
               {isLoadingUniprot ? (
                 <div className="flex items-center">
                   <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                   Loading...
                 </div>
               ) : (
                 <div className="flex items-center">
                   <FileText className="w-4 h-4 mr-2" />
                   Fetch
                 </div>
               )}
             </button>
           </form>
           <div className="text-xs text-blue-600 mt-2">
             Examples: P01911 (HLA-DRB1), P53_HUMAN, or full UniProt IDs
           </div>
         </div>
       </div>

       {/* File Upload */}
       <div className="mb-6">
         <h3 className="text-lg font-medium text-gray-700 mb-3">Upload FASTA File</h3>
         <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-primary-400 transition-colors">
           <Upload className="w-8 h-8 text-gray-400 mx-auto mb-2" />
           <p className="text-gray-600 mb-2">Drag and drop a FASTA file here, or click to browse</p>
           <p className="text-xs text-gray-500 mb-3">
             Supports .fasta, .fa, .txt files. First line should start with &gt; followed by sequence name.
           </p>
           <input
             type="file"
             accept=".fasta,.fa,.txt"
             onChange={handleFileUpload}
             className="hidden"
             id="file-upload"
           />
           <label htmlFor="file-upload" className="btn-primary cursor-pointer">
             Choose File
           </label>
         </div>
       </div>

      {/* Manual Input */}
      <div className="mb-6">
        <h3 className="text-lg font-medium text-gray-700 mb-3">Manual Input</h3>
        <div className="space-y-3">
          <input
            type="text"
            placeholder="Sequence name (optional)"
            value={sequenceName}
            onChange={(e) => setSequenceName(e.target.value)}
            className="input-field"
          />
          <textarea
            placeholder="Paste your protein sequence here (one-letter amino acid codes: ACDEFGHIKLMNPQRSTVWY)"
            value={inputSequence}
            onChange={(e) => setInputSequence(e.target.value)}
            className="input-field h-32 resize-none"
          />
          <div className="text-xs text-gray-500">
            Valid amino acids: A, C, D, E, F, G, H, I, K, L, M, N, P, Q, R, S, T, V, W, Y
          </div>
          <button
            onClick={handleManualInput}
            disabled={!inputSequence.trim()}
            className="btn-primary disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Play className="w-4 h-4 mr-2" />
            Load Sequence
          </button>
        </div>
      </div>

      {/* Current Sequence Display */}
      {currentSequence && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="border-t pt-4"
        >
          <h3 className="text-lg font-medium text-gray-700 mb-3">Current Sequence</h3>
          <div className="bg-gray-50 rounded-lg p-4">
            <div className="font-medium text-gray-800 mb-2">{currentSequence.name}</div>
            {currentSequence.description && (
              <div className="text-sm text-gray-600 mb-3">{currentSequence.description}</div>
            )}
            <div className="text-sm text-gray-700">
              <span className="font-medium">Length:</span> {currentSequence.sequence.length} amino acids
            </div>
            <div className="mt-2 text-xs font-mono bg-white p-2 rounded border overflow-x-auto">
              {currentSequence.sequence}
            </div>
          </div>
        </motion.div>
      )}
    </div>
  )
}

export default InputPane

