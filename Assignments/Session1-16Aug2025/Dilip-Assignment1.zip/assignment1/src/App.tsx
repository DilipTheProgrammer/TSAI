import React, { useState } from 'react'
import { motion } from 'framer-motion'
import Header from './components/Header'
import InputPane from './components/InputPane'
import CNNVisualizer from './components/CNNVisualizer'
import MotifDisplay from './components/MotifDisplay'
import Sidebar from './components/Sidebar'
import { ProteinSequence, KernelConfig, ActivationMap } from './types'
import { demoSequences } from './data/demoSequences'
import { generateActivationMap } from './utils/cnnUtils'

function App() {
  const [currentSequence, setCurrentSequence] = useState<ProteinSequence | null>(null)
  const [kernelConfig, setKernelConfig] = useState<KernelConfig>({
    width: 5,
    stride: 1,
    numKernels: 3,
    weights: [
      [0.2, 0.8, 0.6, 0.3, 0.9], // Kernel 1
      [0.7, 0.1, 0.9, 0.4, 0.2], // Kernel 2
      [0.5, 0.6, 0.2, 0.8, 0.1], // Kernel 3
    ]
  })
  const [activationMap, setActivationMap] = useState<ActivationMap | null>(null)
  const [currentStep, setCurrentStep] = useState(0)
  const [isAnimating, setIsAnimating] = useState(false)
  const [selectedKernel, setSelectedKernel] = useState(0)

  const handleSequenceLoad = (sequence: ProteinSequence) => {
    setCurrentSequence(sequence)
    setCurrentStep(0)
    setIsAnimating(false)
    
    // Generate activation map for the new sequence
    const newActivationMap = generateActivationMap(sequence, kernelConfig)
    setActivationMap(newActivationMap)
  }

  const handleDemoSequence = (sequenceName: string) => {
    const demoSeq = demoSequences.find(seq => seq.name === sequenceName)
    if (demoSeq) {
      handleSequenceLoad(demoSeq)
    }
  }

  const handleKernelConfigChange = (newConfig: Partial<KernelConfig>) => {
    const updatedConfig = { ...kernelConfig, ...newConfig }
    setKernelConfig(updatedConfig)
    
    if (currentSequence) {
      const newActivationMap = generateActivationMap(currentSequence, updatedConfig)
      setActivationMap(newActivationMap)
    }
  }

  const handleStepForward = () => {
    if (activationMap && currentStep < activationMap.positions.length - 1) {
      setCurrentStep(prev => prev + 1)
    }
  }

  const handleStepBackward = () => {
    if (currentStep > 0) {
      setCurrentStep(prev => prev - 1)
    }
  }

  const handleAutoPlay = () => {
    setIsAnimating(!isAnimating)
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="container mx-auto px-4 py-6">
        {/* Input Section - Always Visible */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="mb-6"
        >
          <InputPane 
            onSequenceLoad={handleSequenceLoad}
            onDemoSequence={handleDemoSequence}
            currentSequence={currentSequence}
          />
        </motion.div>

        {/* Analysis Section - Only show when sequence is loaded */}
        {currentSequence && activationMap && (
          <div className="grid grid-cols-1 xl:grid-cols-5 gap-6">
            {/* Left Sidebar - Controls */}
            <div className="xl:col-span-1">
              <Sidebar 
                kernelConfig={kernelConfig}
                onKernelConfigChange={handleKernelConfigChange}
                selectedKernel={selectedKernel}
                onKernelSelect={setSelectedKernel}
                currentStep={currentStep}
                onStepForward={handleStepForward}
                onStepBackward={handleStepBackward}
                onAutoPlay={handleAutoPlay}
                isAnimating={isAnimating}
                totalSteps={activationMap?.positions.length || 0}
              />
            </div>

            {/* Main Analysis Area */}
            <div className="xl:col-span-4 space-y-6">
              {/* Real-time Analysis Results - Top Priority */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.1 }}
              >
                <MotifDisplay
                  sequence={currentSequence}
                  activationMap={activationMap}
                  kernelConfig={kernelConfig}
                  selectedKernel={selectedKernel}
                />
              </motion.div>

              {/* CNN Visualization - Secondary Priority */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.2 }}
              >
                <CNNVisualizer
                  sequence={currentSequence}
                  kernelConfig={kernelConfig}
                  activationMap={activationMap}
                  currentStep={currentStep}
                  selectedKernel={selectedKernel}
                  isAnimating={isAnimating}
                  onStepChange={setCurrentStep}
                />
              </motion.div>
            </div>
          </div>
        )}

        {/* Empty State - When no sequence is loaded */}
        {!currentSequence && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-12"
          >
            <div className="max-w-md mx-auto">
              <div className="text-gray-400 mb-4">
                <svg className="w-16 h-16 mx-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                </svg>
              </div>
              <h3 className="text-lg font-medium text-gray-900 mb-2">Ready to Analyze Protein Sequences</h3>
              <p className="text-gray-600">
                Load a protein sequence above to start the CNN kernel analysis and discover motifs.
              </p>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  )
}

export default App

